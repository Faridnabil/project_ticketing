<?php

namespace App\Providers;

use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Foundation\Support\Providers\RouteServiceProvider as ServiceProvider;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;

class RouteServiceProvider extends ServiceProvider
{
    /**
     * The path to your application's "home" route.
     *
     * Typically, users are redirected here after authentication.
     *
     * @var string
     */
    public const HOME = '/dashboard';

    /**
     * Define your route model bindings, pattern filters, and other route configuration.
     */
    public function boot(): void
    {
        RateLimiter::for('api', function (Request $request) {
            return Limit::perMinute(60)->by($request->user()?->id ?: $request->ip());
        });

        $this->routes(function () {
            Route::middleware('api')
                ->prefix('api')
                ->group(base_path('routes/api.php'));

            Route::middleware('web')
                ->group(base_path('routes/web.php'));
        });
    }

    /**
     * Get the redirect path based on user role.
     *
     * @return string
     */
    public static function redirectTo()
    {
        $user = Auth::user();

        if ($user->hasRole('Admin')) {
            return '/admin/dashboard';
        } elseif ($user->hasRole('Helpdesk')) {
            return '/helpdesk/dashboard';
        } elseif ($user->hasRole('Koordinator')) {
            return '/koordinator/dashboard';
        } elseif ($user->hasRole('Staff Subdit')) {
            return '/staff-subdit/dashboard';
        } elseif ($user->hasRole('SIAK Dev')) {
            return '/siak-dev/dashboard';
        } elseif ($user->hasRole('Pejabat')) {
            return '/pejabat/dashboard';
        } elseif ($user->hasRole('Teknisi Hardware')) {
            return '/teknisi-hardware/dashboard';
        }

        return self::HOME;
    }
}
